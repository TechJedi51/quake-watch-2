# Quake Watch 2
A Ubersicht widget to display the latest quakes via the USGS

# Install
Edit the index.coffee and review/modify the "numberOfQuakes" variable on the 3rd line controls how many quake events are shown.

# Screenshot

![Alt text](/screenshot.png?raw=true)
